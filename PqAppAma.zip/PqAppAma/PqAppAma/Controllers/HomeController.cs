﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using PqAppAma.Models;

namespace PqAppAma.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.total = 0;
            ViewBag.DiscountAmount = 0;
            return View();
        }

       
        public IActionResult Index(PriceQuotationModel model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.DiscountAmount = model.CalculateDiscountAmount();
                ViewBag.total = model.CalculateTotal();
               
            }
            else
            {
                ViewBag.total = 0;
            }
            return View(model);
        }
    }
}
