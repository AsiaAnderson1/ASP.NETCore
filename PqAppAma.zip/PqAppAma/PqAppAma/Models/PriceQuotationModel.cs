﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PqAppAma.Models
{
    public class PriceQuotationModel
    {
         [Required(ErrorMessage = "Please enter a subtotal.")]
         [Range(1,100000.00, ErrorMessage ="Subtotal must be between 1 and 100,000.")]
        public decimal? Subtotal { get; set; }

        [Required(ErrorMessage = "Please enter a Discount Perecent.")]
        [Range(1, 100, ErrorMessage = "Percent must be between 1 and 100")]
        public decimal? DiscountPercent { get; set; }

        public decimal DiscountAmount = 0;
        public decimal total =0;

        public decimal? CalculateDiscountAmount()
        {
            decimal? DiscountAmount = Subtotal * DiscountPercent;
            return DiscountAmount;
        }

        public decimal? CalculateTotal()
        {
            decimal? total = Subtotal - DiscountAmount;
            return total;
        }
    }
}
