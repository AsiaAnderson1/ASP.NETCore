﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using PqAppAma.Models;

namespace PqAppAma.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
           ViewBag.total = 0;
           ViewBag.DiscountAmount= 0;
            return View();
        }

       [HttpPost]
        public IActionResult Index( PriceQuotationModel model)
        {
            if (ModelState.IsValid)
            {
                /*Here I didn't have the proper variables associated
                now that I corrected the variable names I do not get runtime binding error but it still isn't calculating*/
                ViewBag.DiscountAmount = model.CalculateDiscountAmount();
                ViewBag.total = model.CalculateTotal();
               
            }
            else
            {
                ViewBag.DiscountAmount= 0;
                ViewBag.total = 0;
                 
            }
            return View(model);
        }
    }
}
