﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TipCalculator.Models;

namespace TipCalculator.Controllers
{
    public class HomeController : Controller
    {
        //Gives us default view and view when we hit clear.
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Fifteen = 0;
            ViewBag.Twenty = 0;
            ViewBag.TwentyFive = 0;
            return View();
        }

        [HttpPost]
        public IActionResult Index(Calculator calculator)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Fifteen = calculator.CalculateTip(.15);
                ViewBag.Twenty = calculator.CalculateTip(.2);
                ViewBag.TwentyFive = calculator.CalculateTip(.25);
            }
            else
            {
                ViewBag.Fifteen = 0;
                ViewBag.Twenty = 0;
                ViewBag.TwentyFive = 0;
            }

            return View(calculator);
        }
    }
}
