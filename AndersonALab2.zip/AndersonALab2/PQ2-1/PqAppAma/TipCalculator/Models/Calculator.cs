﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TipCalculator.Models
{
    public class Calculator
    {
        // need something to hold meal
        // need to calculate 15,20,25 percent tips
        [Required(ErrorMessage = "Please enter a value for the cost of the meal.")]
        [Range(0.01, 1000000, ErrorMessage = "Cost of meal must be greater than zero.")]
        [Display(Name = "Cost of meal.")]
        public double? MealCost { get; set; }


        public double CalculateTip(double tipPercent)
        {
            return MealCost.HasValue ? MealCost.Value * tipPercent : 0;
        }

        //Hit the calculate button
        //Hit the clear button

    }
}
